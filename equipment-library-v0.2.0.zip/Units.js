var linear = {"0": {"name": "meters", "factor": 1}, "2": {"name": "international feet", "factor": 0.3048}, "29": {"name": "US survey feet", "factor": 0.3048006096012192}};
