import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import org.qfield
import org.qgis
import "Core.js" as Core
import "Catalog.js" as Catalog

Item {
    id: plugin
    objectName: "equipmentLibraryPlugin"
    property var projectInfo: iface.findItemByObjectName("projectInfo")
    property var equipmentLayer: null
    property var templateLayer: null
    property string attachedPath: ""
    property bool layerEditing: false
    property bool busy: false
    property string message: "Open your job, then add the equipment library."
    property string positionText: "Position not checked"
    property var equipmentNames: Object.keys(Catalog.equipment)
    property var pointOptions: []
    property string lastDevice: ""

    function projectPath() {
        return projectInfo ? Core.localPath(projectInfo.filePath) : "";
    }
    function api() {
        return {
            findLayer: function(path) {
                if (attachedPath === path && equipmentLayer) return equipmentLayer;
                // A previous activation may have left a live edit buffer. Never
                // silently reuse it, or duplicate it, when its state is unknown.
                var layers = ProjectUtils.mapLayers(qgisProject);
                var expected = "Equipment points Â· " + path.split("/").pop();
                for (var id in layers) {
                    if (layers[id].name === expected)
                        throw new Error("Equipment layer already exists from an earlier plugin activation. Close and reopen the job to reconnect it safely.");
                }
                return null;
            },
            exists: function(path) { return FileUtils.fileExists(path); },
            readSeed: function() {
                if (!templateLayer) templateLayer = LayerUtils.loadVectorLayer(Core.localPath(Qt.resolvedUrl("seed.gpkg")), "Equipment seed", "ogr");
                if (!templateLayer || !templateLayer.isValid) throw new Error("The installed equipment schema could not be loaded.");
                return templateLayer;
            },
            writeSeed: function(path, seedLayer) {
                // Use QField's vector writer; file-content reads are restricted
                // to the active project and cannot read app-plugin assets.
                return LayerUtils.saveVectorLayerAs(seedLayer, path, "GPKG") !== "";
            },
            loadLayer: function(path) {
                return LayerUtils.loadVectorLayer(path, "Equipment points Â· " + path.split("/").pop(), "ogr");
            },
            validLayer: function(layer) { return layer.isValid; },
            addLayer: function(layer) { return ProjectUtils.addMapLayer(qgisProject, layer); },
            isEditing: function(layer) { return plugin.layerEditing; },
            uuid: function() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
                    var r = Math.floor(Math.random() * 16);
                    return (c === "x" ? r : (r & 3) | 8).toString(16);
                });
            },
            insert: function(layer, attrs, shot) {
                var geom = GeometryUtils.createGeometryFromWkt("POINT Z (" + shot.longitude + " " + shot.latitude + " " + shot.elevation + ")");
                var feature = FeatureUtils.createFeature(layer, geom);
                for (var name in attrs) {
                    if (!feature.setAttribute(name, attrs[name])) throw new Error("Could not populate field: " + name);
                }
                return LayerUtils.addFeature(layer, feature);
            }
        };
    }
    function rememberLayer(layer) {
        equipmentLayer = layer;
        attachedPath = Core.paths(projectPath()).data;
        layerEditing = false;
    }
    function attach(create) {
        if (busy) return;
        busy = true;
        try {
            var layer = Core.ensureLayer(api(), projectPath(), create);
            if (layer) {
                rememberLayer(layer);
                message = "Equipment library ready for this job. Select your equipment and point below.";
            }
        } catch (e) {
            message = String(e.message || e);
            iface.logMessage("Equipment Library: " + message);
        } finally { busy = false; }
    }
    function updateChoices() {
        var name = equipmentBox.currentIndex >= 0 ? equipmentNames[equipmentBox.currentIndex] : "";
        pointOptions = Catalog.equipment[name] || [];
        pointBox.currentIndex = -1;
    }
    function refreshPosition() {
        var pos = iface.positioning();
        var info = pos.positionInformation;
        var device = String(pos.deviceId || info.sourceName || "");
        if (device !== lastDevice) { roverConfirmed.checked = false; lastDevice = device; }
        var details = device || "No positioning source selected";
        if (pos.active && info.longitudeValid && info.latitudeValid) {
            details += "\n" + Number(info.latitude).toFixed(8) + ", " + Number(info.longitude).toFixed(8);
            details += "\nSolution: " + String(info.fixStatusDescription || info.quality);
            if (info.haccValid) details += " | H: " + Number(info.hacc).toFixed(3) + " m";
        } else details += "\nNo valid active position";
        positionText = details;
    }
    function savePoint() {
        if (busy) return;
        busy = true;
        try {
            var option = pointBox.currentIndex >= 0 ? pointOptions[pointBox.currentIndex] : null;
            var pos = iface.positioning();
            var result = Core.collect(api(), Catalog.equipment, projectPath(), {
                job: jobField.text, equipment: equipmentBox.currentIndex >= 0 ? equipmentNames[equipmentBox.currentIndex] : "",
                asset: equipmentId.text, code: option ? option.code : "", number: numberField.text,
                description: descriptionField.text, notes: notesField.text, heightNote: heightField.text
            }, {active: pos.active, valid: pos.valid, info: pos.positionInformation,
                device: pos.deviceId, antennaHeight: pos.antennaHeight}, Date.now(), fixedOnly.checked, roverConfirmed.checked);
            rememberLayer(result.layer);
            message = "Saved " + result.attributes.code + " for " + result.attributes.equipment_id + ".";
            iface.mainWindow().displayToast(message);
        } catch (e) {
            message = String(e.message || e);
            iface.logMessage("Equipment Library: " + message);
        } finally { busy = false; }
    }
    function configure() { panel.open(); refreshPosition(); }

    ToolButton {
        id: equipmentButton
        text: "EQ"
        font.bold: true
        implicitWidth: 52
        implicitHeight: 52
        onClicked: plugin.configure()
        ToolTip.text: "Equipment Library"
        ToolTip.visible: hovered
        Accessible.name: "Equipment Library"
    }
    Dialog {
        id: panel
        parent: iface.mainWindow().contentItem
        modal: true
        title: "Equipment Library Â· Pilot 0.1.1"
        width: Math.min(480, parent.width - 16)
        height: Math.min(780, parent.height - 24)
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2
        standardButtons: Dialog.Close
        contentItem: ScrollView {
            clip: true
            contentWidth: availableWidth
            ColumnLayout {
                width: parent.width
                spacing: 10
                Label { text: "Job: " + (plugin.projectPath().split("/").pop() || "none open"); wrapMode: Text.Wrap; Layout.fillWidth: true }
                Button { text: "Add Equipment Library to This Job"; enabled: !plugin.busy; Layout.fillWidth: true; onClicked: plugin.attach(true) }
                Label { text: plugin.message; wrapMode: Text.Wrap; Layout.fillWidth: true }
                Label { text: "Job ID" }
                TextField { id: jobField; objectName: "jobField"; placeholderText: "Job name or number"; Layout.fillWidth: true }
                Label { text: "Equipment type" }
                ComboBox {
                    id: equipmentBox; objectName: "equipmentBox"; model: plugin.equipmentNames; currentIndex: -1
                    displayText: currentIndex < 0 ? "Choose equipment" : currentText
                    Layout.fillWidth: true; onCurrentIndexChanged: plugin.updateChoices()
                }
                Label { text: "Equipment / vessel ID" }
                TextField { id: equipmentId; objectName: "equipmentId"; placeholderText: "For example EX-01"; Layout.fillWidth: true }
                Label { text: "Point to measure" }
                ComboBox {
                    id: pointBox; objectName: "pointBox"; model: plugin.pointOptions; textRole: "label"; currentIndex: -1
                    enabled: equipmentBox.currentIndex >= 0
                    displayText: currentIndex < 0 ? "Choose point" : currentText
                    Layout.fillWidth: true
                }
                Label { text: "Code: " + (pointBox.currentIndex >= 0 ? plugin.pointOptions[pointBox.currentIndex].code : "â€”"); font.bold: true }
                TextField { id: numberField; placeholderText: "Tooth / repeat number (optional)"; inputMethodHints: Qt.ImhDigitsOnly; Layout.fillWidth: true }
                TextArea { id: descriptionField; objectName: "descriptionField"; placeholderText: "Exact physical point measured (required)"; wrapMode: TextEdit.Wrap; Layout.fillWidth: true }
                TextArea { id: heightField; placeholderText: "Height reference / correction setup notes"; wrapMode: TextEdit.Wrap; Layout.fillWidth: true }
                TextArea { id: notesField; placeholderText: "Notes (optional)"; wrapMode: TextEdit.Wrap; Layout.fillWidth: true }
                Label { text: plugin.positionText; wrapMode: Text.Wrap; Layout.fillWidth: true }
                CheckBox { id: roverConfirmed; objectName: "roverConfirmed"; text: "I confirmed this source is my external rover"; Layout.fillWidth: true }
                CheckBox { id: fixedOnly; text: "Require RTK Fixed"; checked: true; Layout.fillWidth: true }
                Label { text: "Uses the active GNSS stream height. No extra pole-height or vertical correction is applied by this plugin."; wrapMode: Text.Wrap; Layout.fillWidth: true }
                Button { text: "Save Rover Point"; enabled: !plugin.busy; Layout.fillWidth: true; onClicked: plugin.savePoint() }
            }
        }
    }
    Connections {
        target: iface
        function onLoadProjectTriggered() {
            panel.close(); equipmentLayer = null; attachedPath = ""; layerEditing = false;
            jobField.text = ""; equipmentId.text = ""; equipmentBox.currentIndex = -1;
            descriptionField.text = ""; notesField.text = ""; heightField.text = ""; numberField.text = "";
            roverConfirmed.checked = false;
        }
        function onLoadProjectEnded() { restoreTimer.restart(); }
    }
    Connections {
        target: plugin.equipmentLayer
        function onEditingStarted() { plugin.layerEditing = true; }
        function onEditingStopped() { plugin.layerEditing = false; }
    }
    Timer { id: restoreTimer; interval: 250; onTriggered: plugin.attach(false) }
    Timer { interval: 1000; repeat: true; running: panel.visible; onTriggered: plugin.refreshPosition() }
    Component.onCompleted: {
        iface.addItemToPluginsToolbar(equipmentButton);
        restoreTimer.start();
    }
}
