var equipment = {
  "Excavator": [
    {
      "label": "Antenna 1",
      "code": "ANT"
    },
    {
      "label": "Antenna 2",
      "code": "ANT2"
    },
    {
      "label": "Boom Pin",
      "code": "PIN"
    },
    {
      "label": "Stick Pin",
      "code": "ELBOW"
    },
    {
      "label": "Bucket Pin",
      "code": "WRIST"
    },
    {
      "label": "Bucket Teeth / selected tip",
      "code": "TOOTH"
    },
    {
      "label": "Outside Tooth - Port",
      "code": "TOOTHP"
    },
    {
      "label": "Outside Tooth - Starboard",
      "code": "TOOTHS"
    }
  ],
  "Cutter Suction Dredge": [
    {
      "label": "Antenna 1",
      "code": "ANT"
    },
    {
      "label": "Antenna 2",
      "code": "ANT2"
    },
    {
      "label": "Ladder Pin / Trunnion Center",
      "code": "TRUN"
    },
    {
      "label": "Cutter Head",
      "code": "CUTTER"
    },
    {
      "label": "Port Reference",
      "code": "PORT"
    },
    {
      "label": "Starboard Reference",
      "code": "STBD"
    },
    {
      "label": "Centerline Aft",
      "code": "AFT"
    },
    {
      "label": "Centerline Forward",
      "code": "FWD"
    }
  ],
  "Survey Boat": [
    {
      "label": "Antenna 1",
      "code": "ANT"
    },
    {
      "label": "Antenna 2",
      "code": "ANT2"
    },
    {
      "label": "IMU",
      "code": "IMU"
    },
    {
      "label": "Sonar - Single Beam",
      "code": "XDCR"
    },
    {
      "label": "Sonar - Multibeam",
      "code": "MBES"
    }
  ]
};
