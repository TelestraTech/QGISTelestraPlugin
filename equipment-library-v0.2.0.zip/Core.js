/* Equipment Library core. Same functions are exercised by the test harness. */
function localPath(value) {
    var path = String(value || '');
    if (path.indexOf('file://') === 0) {
        path = decodeURIComponent(path.slice(7));
        if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
    }
    return path.replace(/\\/g, '/');
}
function paths(projectPath) {
    var path = localPath(projectPath);
    if (!/\.(qgs|qgz)$/i.test(path) || path.indexOf('/') < 0 || path.indexOf('://') >= 0)
        throw new Error('Open a saved local job project first.');
    var slash = path.lastIndexOf('/');
    var stem = path.slice(slash + 1).replace(/\.(qgs|qgz)$/i, '');
    return {project: path, data: path.slice(0, slash + 1) + stem + '.equipment-library.gpkg'};
}
function ensureLayer(api, projectPath, create) {
    var target = paths(projectPath).data;
    var found = api.findLayer(target);
    if (found) return found;
    if (!api.exists(target)) {
        if (!create) return null;
        var bytes = api.readSeed();
        if (!bytes || !api.writeSeed(target, bytes))
            throw new Error('Could not create the equipment database in this job folder. Use a writable local job.');
    }
    var layer = api.loadLayer(target);
    if (!layer || !api.validLayer(layer))
        throw new Error('The equipment database could not be opened. No measurements were replaced.');
    if (!api.addLayer(layer)) throw new Error('QField could not add the equipment layer to this job.');
    return layer;
}
function validateSelection(catalog, input) {
    if (!String(input.job || '').trim()) throw new Error('Enter the job ID.');
    if (!String(input.asset || '').trim()) throw new Error('Enter the equipment / vessel ID.');
    if (!String(input.description || '').trim()) throw new Error('Describe the exact physical point measured.');
    var options = catalog[input.equipment] || [];
    var item = null;
    for (var i = 0; i < options.length; i++) if (options[i].code === input.code) item = options[i];
    if (!item) throw new Error('Choose a point for the selected equipment type.');
    if (input.number !== '' && input.number !== undefined && (!/^\d+$/.test(String(input.number)) || Number(input.number) < 1))
        throw new Error('Point number must be a positive whole number, or blank.');
    return item;
}
function positionSnapshot(position, now, requireFixed, confirmed) {
    if (!confirmed) throw new Error('Confirm that the selected positioning source is your external rover.');
    var info = position.info || {};
    if (!position.active || !position.valid || !info.latitudeValid || !info.longitudeValid || !info.elevationValid)
        throw new Error('A valid GNSS position and height are required.');
    var lon = Number(info.longitude), lat = Number(info.latitude), z = Number(info.elevation);
    if (!isFinite(lon) || !isFinite(lat) || !isFinite(z) || lon < -180 || lon > 180 || lat < -90 || lat > 90)
        throw new Error('The GNSS coordinates are invalid.');
    var timestamp = new Date(info.utcDateTime).getTime();
    if (!isFinite(timestamp) || Math.abs(now - timestamp) > 15000)
        throw new Error('GNSS position is stale or has no valid observation time. Check the rover clock and connection.');
    if (requireFixed && Number(info.quality) !== 4)
        throw new Error('RTK Fixed is required. Current solution: ' + String(info.fixStatusDescription || info.quality));
    return {longitude: lon, latitude: lat, elevation: z, observed: new Date(timestamp).toISOString(),
        source: String(position.device || info.sourceName || ''), fix: String(info.fixStatusDescription || ''),
        quality: Number(info.quality), hacc: info.haccValid && isFinite(info.hacc) ? Number(info.hacc) : null,
        vacc: info.vaccValid && isFinite(info.vacc) ? Number(info.vacc) : null,
        antennaHeight: isFinite(position.antennaHeight) ? Number(position.antennaHeight) : null};
}
function values(input, item, shot, now, uniqueId) {
    return {point_id: uniqueId, job_id: input.job.trim(), equipment_type: input.equipment,
        equipment_id: input.asset.trim(), code: item.code, point_label: item.label,
        point_number: input.number === '' || input.number === undefined ? null : Number(input.number),
        measured_point: input.description.trim(), notes: String(input.notes || ''),
        recorded_at: new Date(now).toISOString(), observed_at: shot.observed,
        longitude: shot.longitude, latitude: shot.latitude, gnss_height_m: shot.elevation,
        fix_status: shot.fix, gnss_quality: shot.quality, h_accuracy_m: shot.hacc, v_accuracy_m: shot.vacc,
        source_name: shot.source, antenna_height_m: shot.antennaHeight,
        height_note: String(input.heightNote || ''), review_status: 'Unreviewed', schema_version: 1};
}
function collect(api, catalog, projectPath, input, position, now, requireFixed, confirmed) {
    var item = validateSelection(catalog, input);
    var shot = positionSnapshot(position, now, requireFixed, confirmed);
    var layer = ensureLayer(api, projectPath, true);
    if (api.isEditing(layer)) throw new Error('Finish editing the equipment layer before using the plugin, so this observation can be committed immediately.');
    var attrs = values(input, item, shot, now, api.uuid());
    if (!api.insert(layer, attrs, shot)) throw new Error('QField could not save this observation. Check the log; do not assume it was stored.');
    return {layer: layer, attributes: attrs, point: shot};
}
function csvCell(value, text) {
    if (value === null || value === undefined) return '';
    var s = String(value);
    if (text && /^[\s]*[=+@-]/.test(s)) s = "'" + s;
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function exportCsv(rows, options, project) {
    if (!rows.length) throw new Error('No saved points match this export.');
    var projected = options.mode === 'projected';
    if (projected && (!project || !project.authid || project.geographic || !isFinite(project.metersPerUnit) || project.metersPerUnit <= 0))
        throw new Error('Choose a valid projected survey CRS with meter or foot units.');
    var headers = projected ? ['Name','Code','Easting','Northing','Elevation','CS name','Coordinate units','Height reference'] :
        ['Name','Code','Longitude','Latitude','GNSS height (m)','CS name','Coordinate units','Height reference'];
    var extra = ['job_id','equipment_type','equipment_id','point_label','point_number','measured_point','notes','point_id','observed_at','recorded_at','fix_status','gnss_quality','h_accuracy_m','v_accuracy_m','source_name','antenna_height_m','height_note','review_status'];
    headers = headers.concat(extra);
    var lines = [headers.map(function(v){return csvCell(v,false);}).join(',')];
    rows.forEach(function(r) {
        var lon = Number(r.longitude), lat = Number(r.latitude), z = Number(r.gnss_height_m);
        if (r.longitude === null || r.latitude === null || r.gnss_height_m === null || !isFinite(lon) || !isFinite(lat) || !isFinite(z))
            throw new Error('A saved point has missing coordinates or height; no CSV was written.');
        var name = r.equipment_id + '_' + r.code + (r.point_number === null || r.point_number === undefined ? '' : '_' + r.point_number) + '_' + r.point_id;
        var xyz = projected ? project.transform(lon,lat) : {x:lon,y:lat};
        if (!xyz || !isFinite(xyz.x) || !isFinite(xyz.y)) throw new Error('Coordinate transformation failed; no CSV was written.');
        var values = [name,r.code,xyz.x,xyz.y,projected ? z/project.metersPerUnit : z,
            projected ? project.description + ' / ' + project.authid + ' / ' + project.units : 'EPSG:4326 / WGS 84',
            projected ? project.units : 'degrees; height meters', 'GNSS stream height; no vertical datum transformation'];
        values = values.concat(extra.map(function(key){return r[key];}));
        lines.push(values.map(function(value,i){return csvCell(value,typeof value === 'string');}).join(','));
    });
    return '\ufeff' + lines.join('\r\n') + '\r\n';
}
